package com.design.builder;

public interface Packing {

	public String pack();
}
