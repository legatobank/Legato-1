package com.design.builder;

public class Pepsi extends ColdDrink {

	@Override
	public String name() {
		// TODO Auto-generated method stub
		return "Pepsi";
	}

	@Override
	public float price() {
		// TODO Auto-generated method stub
		return 35.0f;
	}

}
