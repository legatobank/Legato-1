package com.design.factory;

public interface Shape {

	void draw();
}
