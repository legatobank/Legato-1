package com.design.adapter;

public class AdapterPatternDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AudioPlayer audioPlayer = new AudioPlayer();
		
		audioPlayer.play("mp3", "beyond");
		audioPlayer.play("mp4", "alone");
		audioPlayer.play("vlc", "far far");
		audioPlayer.play("avi", "mind me");
	}

}
