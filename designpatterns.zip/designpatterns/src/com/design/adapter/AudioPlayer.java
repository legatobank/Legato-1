package com.design.adapter;

public class AudioPlayer implements MediaPlayer {

	MediaAdapter mediaAdapter;
	@Override
	public void play(String audioType, String fileName) {
		// TODO Auto-generated method stub
		if(audioType.equals("mp3"))
			System.out.println("Playing MP3 file. Name : " + fileName);
		
		else if (audioType.equals("vlc") || audioType.equals("mp4"))
		{
			mediaAdapter = new MediaAdapter(audioType);
			mediaAdapter.play(audioType, fileName);
		}
		else {
			System.out.println("Invalid Media. " + audioType + " Format Not supported");
		}
	}

}
