package com.design.singleton;

public class SingleObject {

	/**
	 * @param args
	 */

		// TODO Auto-generated method stub

		private static SingleObject instance =  new SingleObject();
		
		private SingleObject() {}
		
		public static SingleObject getInstance()
		{
			return instance;
		}

		public void showMessage()
		{
			System.out.println("Hello World!");
		}
}
