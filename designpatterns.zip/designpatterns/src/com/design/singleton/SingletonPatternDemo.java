package com.design.singleton;

public class SingletonPatternDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
           SingleObject object = SingleObject.getInstance();
           object.showMessage();
	}

}
