package com.design.criteria;

import java.util.ArrayList;
import java.util.List;

public class CriteriaPatternDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Person> persons = new ArrayList<Person>();
		
		persons.add(new Person("a", "male", "single"));
		persons.add(new Person("b", "male", "married"));
		persons.add(new Person("c", "female", "married"));
		persons.add(new Person("d", "female", "single"));
		persons.add(new Person("e", "male", "single"));
		persons.add(new Person("f", "male", "single"));
		
		Criteria male = new CriteriaMale();
		Criteria female = new CriteriaFemale();
		Criteria single = new CriteriaSingle();
		Criteria singleMale = new AndCriteria(male, single);
		Criteria singleOrFemale = new OrCriteria(female, single);
		
		System.out.println("Males");
		printPersons(male.meetCriteria(persons));
		System.out.println("Females");
		printPersons(female.meetCriteria(persons));
		System.out.println("Single Males ");
		printPersons(singleMale.meetCriteria(persons));
		System.out.println("Single or Females");
		printPersons(singleOrFemale.meetCriteria(persons));
	 }
	
	public static void printPersons(List<Person> persons) {
		for(Person person : persons)
		{
			System.out.println("Person : Name : " + person.getName() + " gender : " + person.getGender() + " Marital Status : " + person.getMaritalStatus());
		}
	}

}
