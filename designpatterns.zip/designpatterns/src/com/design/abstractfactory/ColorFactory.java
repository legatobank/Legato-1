package com.design.abstractfactory;

public class ColorFactory extends AbstractFactory{

	@Override
	Color getColor(String color) {
		// TODO Auto-generated method stub
		
		if(color == null)
			return null;
		if(color.equals("red"))
			return new Red();
		else if(color.equals("green"))
			return new Green();
		else if(color.equals("blue"))
			return new Blue();
		return null;
	}

	@Override
	Shape getShape(String shape) {
		// TODO Auto-generated method stub
		return null;
	}

}
