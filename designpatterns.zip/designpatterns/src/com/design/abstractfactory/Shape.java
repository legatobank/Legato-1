package com.design.abstractfactory;

public interface Shape {

	void draw();
}
